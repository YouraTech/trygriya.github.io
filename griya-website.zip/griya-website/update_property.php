<?php

session_start();

if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die('CSRF token mismatch!');
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "griya_idn";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = intval($_POST['id']);
$title = $conn->real_escape_string($_POST['title']);
$price = $conn->real_escape_string($_POST['price']);
$description = $conn->real_escape_string($_POST['description']);
$ruangan = (int)$_POST['ruangan'];
$bed = (int)$_POST['bed'];
$bath = (int)$_POST['bath'];
$status = $conn->real_escape_string($_POST['status']);
$location = $conn->real_escape_string($_POST['location']);
$type = $conn->real_escape_string($_POST['type']);
$image_link = $conn->real_escape_string($_POST['image_link']);

$imageNames = [];
$targetDir = "uploads/";

if (isset($_FILES['image'])) {
    foreach ($_FILES['image']['name'] as $key => $imageName) {
        if ($imageName) {
            $fileExtension = pathinfo($imageName, PATHINFO_EXTENSION);
            if (!in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif'])) {
                echo "Invalid file type.";
                exit();
            }

            $targetFilePath = $targetDir . basename($imageName);
            if (move_uploaded_file($_FILES['image']['tmp_name'][$key], $targetFilePath)) {
                $imageNames[] = $imageName;
            } else {
                echo "Failed to upload file: " . $imageName;
                exit();
            }
        }
    }
}

$imageNamesString = implode(",", $imageNames);

$stmt = $conn->prepare("UPDATE properties SET title = ?, price = ?, description = ?, location = ?, type = ?, images = ?, bath = ?, ruangan = ?, bed = ?, status = ?, image_link = ? WHERE id = ?");
$stmt->bind_param("ssssssiiisss", $title, $price, $description, $location, $type, $imageNamesString, $bath, $ruangan, $bed, $status, $image_link, $id);

if ($stmt->execute()) {
    header("Location: update_admin.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>