<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "griya_idn";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT id, title, price, description, location, type, images, status, ruangan, bed, bath, image_link FROM properties";
$result = $conn->query($sql);

$properties = [
    'Featured' => [],
    'For Sell' => [],
    'For Rent' => []
];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $status = $row['status'];
        $images = explode(',', $row["images"]);
        
        $properties[$status][] = [
            'id' => $row['id'],
            'title' => $row["title"],
            'price' => $row["price"],
            'description' => $row["description"],
            'location' => $row["location"],
            'type' => $row["type"],
            'ruangan' => $row["ruangan"],
            'bed' => $row["bed"],
            'bath' => $row["bath"],
            'image_link' => $row["image_link"],
            'image' => !empty($images[0]) ? 'uploads/' . $images[0] : 'img/default.jpg',
            'status' => $status
        ];
    }
} else {
    echo "0 hasil";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>GRIYA.ID | WEBSITE</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Favicon -->
    <link href="img/icon.png" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap"
        rel="stylesheet" />

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet" />
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet" />
</head>
<style>
.property-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}
</style>

<body style="background-color: #1e3657">
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-dark" style="width: 3rem; height: 3rem" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Navbar Start -->
        <div class="container-fluid nav-bar">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
                <a href="index.php" class="navbar-brand d-flex align-items-center text-center">
                    <div class="p-2 me-4">
                        <img class="img-fluid"
                            src="https://griya.id/wp-content/uploads/2024/01/logo-logo-internal-e1705216276269.png"
                            alt="Icon" style="width: 170px; height: 50px" />
                    </div>
                    <h1 style="color: #0d6efd"></h1>
                </a>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto">
                        <a href="#" class="nav-item nav-link"></a>
                        <a href="#" class="nav-item nav-link"></a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link nav-item"></a>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="admin.php" class="nav-link nav-item">Admin Home</a>
                        </div>
                        <div class="nav-item dropdown">
                            <a href="update_admin.php" class="nav-link nav-item active">Edit pages</a>
                        </div>
                        <a href="edit.php" class="nav-item nav-link">Marketing Tools</a>
                    </div>
                    <a href="logout.php" class="btn btn-dark px-3 d-none d-lg-flex">LOG OUT</a>
                </div>
            </nav>
        </div>
        <!-- Navbar End -->

        <!-- Header Start -->
        <div class="container-fluid header bg-white p-0">
            <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
                <div class="col-md-6 p-5 mt-lg-5">
                    <h1 class="display-5 animated fadeIn mb-4">Update Data</h1>
                    <nav aria-label="breadcrumb animated fadeIn">
                        <ol class="breadcrumb text-uppercase">
                            <li class="breadcrumb-item"><a href="index.php" style="color: rgb(45, 45, 204)">Home</a>
                            </li>
                            <li class="breadcrumb-item"><a href="admin.php" style="color: rgb(21, 21, 173)">Admin</a>
                            </li>
                            <li class="breadcrumb-item text-body active" aria-current="page">Update</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-md-6 animated fadeIn">
                    <img class="img-fluid" src="img/edit-img.png" alt="" />
                </div>
            </div>
        </div>
        <!-- Header End -->

        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-0 gx-5 align-items-end">
                    <div class="col-lg-6">
                        <div class="text-start mx-auto mb-5 wow slideInLeft" data-wow-delay="0.1s">
                            <h1 class="mb-3">Data untuk Diedit</h1>
                            <p>Slahkan tekan icon edit untuk mengedit konten, dan icon sampah untuk menghapus konten.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6 text-start text-lg-end wow slideInRight" data-wow-delay="0.1s">
                        <ul class="nav nav-pills d-inline-flex justify-content-end mb-5">
                            <li class="nav-item me-2">
                                <a class="btn btn-outline-dark active" data-bs-toggle="pill" href="#tab-1">Featured</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="btn btn-outline-dark" data-bs-toggle="pill" href="#tab-2">For Sell</a>
                            </li>
                            <li class="nav-item me-0">
                                <a class="btn btn-outline-dark" data-bs-toggle="pill" href="#tab-3">Pre-Order</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane fade show p-0 active">
                        <div class="row g-4">
                            <?php foreach ($properties as $status => $items): ?>
                            <?php foreach ($items as $item): ?>
                            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                                <div class="property-item rounded overflow-hidden position-relative">
                                    <div class="position-relative overflow-hidden">
                                        <a href="<?php echo htmlspecialchars($item['image_link'], ENT_QUOTES, 'UTF-8'); ?>"
                                            target="_blank">
                                            <img class="img-fluid"
                                                src="<?php echo htmlspecialchars($item['image'], ENT_QUOTES, 'UTF-8'); ?>"
                                                alt="<?php echo htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8'); ?>" />
                                        </a>

                                        <!-- Tombol Edit dan Delete -->
                                        <a href="edit_property.php?id=<?php echo $item['id']; ?>"
                                            class="btn btn-primary position-absolute top-0 end-0 m-2 me-5">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        <a href="delete_property.php?id=<?php echo $item['id']; ?>"
                                            class="btn btn-danger position-absolute top-0 end-0 m-2"
                                            onclick="return confirm('Are you sure you want to delete this item?');">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                        <div
                                            class="bg-dark rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">
                                            <?php echo htmlspecialchars($item['status'], ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                        <div
                                            class="bg-white rounded-top text-dark position-absolute start-0 bottom-0 mx-4 pt-1 px-3">
                                            <?php echo htmlspecialchars($item['type'], ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                    </div>
                                    <div class="p-4 pb-0">
                                        <h5 class="text-dark mb-3">
                                            Rp <?php echo htmlspecialchars($item['price'], ENT_QUOTES, 'UTF-8'); ?>
                                        </h5>
                                        <a class="d-block h5 mb-2"
                                            href=""><?php echo htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8'); ?></a>
                                        <p><i
                                                class="fa fa-map-marker-alt text-dark me-2"></i><?php echo htmlspecialchars($item['location'], ENT_QUOTES, 'UTF-8'); ?>
                                        </p>
                                    </div>
                                    <div class="d-flex border-top">
                                        <small class="flex-fill text-center border-end py-2"><i
                                                class="fa fa-cube text-dark me-2"></i><?php echo htmlspecialchars($item['ruangan'], ENT_QUOTES, 'UTF-8'); ?>
                                            Ruangan</small>
                                        <small class="flex-fill text-center border-end py-2"><i
                                                class="fa fa-bed text-dark me-2"></i><?php echo htmlspecialchars($item['bed'], ENT_QUOTES, 'UTF-8'); ?>
                                            Kamar</small>
                                        <small class="flex-fill text-center py-2"><i
                                                class="fa fa-bath text-dark me-2"></i><?php echo htmlspecialchars($item['bath'], ENT_QUOTES, 'UTF-8'); ?>
                                            Kamar Mandi</small>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div id="tab-2" class="tab-pane fade show p-0">
                        <div class="row g-4">
                        </div>
                    </div>
                    <div id="tab-3" class="tab-pane fade show p-0">
                        <div class="row g-4">
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Footer Start -->
        <div class="container-fluid bg-dark text-white-50 footer wow fadeIn" data-wow-delay="0.1s">
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="text-center">
                            &copy; <a href="https://www.instagram.com/griya.idn" target="blank">Copyright PT.
                                Artha Adhi Sentosa
                                NPA REI 01.01695</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>