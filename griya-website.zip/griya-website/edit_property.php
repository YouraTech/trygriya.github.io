<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "griya_idn";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = intval($_GET['id']);

$sql = "SELECT * FROM properties WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$property = $result->fetch_assoc();

if (!$property) {
    die("Property not found!");
}

$stmt->close();
$conn->close();

$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>GRIYA.ID | ABOUT</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Favicon -->
    <link href="img/icon.png" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap"
        rel="stylesheet" />

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet" />
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet" />
    <style>
    .card {
        max-width: 95%;
        margin: 2rem auto;
        padding: 2rem;
        border-radius: 0.75rem;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        background-color: #ffffff;
        border: 1px solid #eaeaea;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    .form-control,
    .form-select {
        border-radius: 0.5rem;
        padding: 0.75rem;
        border: 1px solid #d1d1d1;
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #007bff;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        background-color: #f8f9fa;
    }

    .form-control-file {
        padding: 0.5rem;
    }

    .btn-dark {
        border-radius: 0.5rem;
        background-color: #003468;
        border-color: #003468;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .btn-dark:hover {
        background-color: #0056b3;

        transform: scale(1.05);
    }

    textarea.form-control {
        resize: none;
        height: auto;
        min-height: 100px;
    }

    @media (min-width: 768px) {
        .card {
            max-width: 90%;
        }
    }
    </style>
</head>

<body style="background-color: #1e3657">

    <!-- Navbar Start -->
    <div class="container-fluid nav-bar container-xxl">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
            <a href="index.php" class="navbar-brand d-flex align-items-center text-center">
                <div class="p-2 me-4">
                    <img class="img-fluid"
                        src="https://griya.id/wp-content/uploads/2024/01/logo-logo-internal-e1705216276269.png"
                        alt="Icon" style="width: 150px; height: 50px" />
                </div>
                <h1 style="color: #0d6efd"></h1>
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto">
                    <a href="#" class="nav-item nav-link"></a>
                    <a href="#" class="nav-item nav-link"></a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link nav-item"></a>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="admin.php" class="nav-link nav-item">Home</a>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="update_admin.php" class="nav-link nav-item">Edit pages</a>
                    </div>
                    <a href="edit.php" class="nav-item nav-link">Marketing Tools</a>
                </div>
                <a href="logout.php" class="btn btn-dark px-3 d-none d-lg-flex">LOG OUT</a>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

    <!-- Header Start -->
    <div class="container-fluid header bg-white p-0">
        <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
            <div class="col-md-6 p-5 mt-lg-5">
                <h1 class="display-5 animated fadeIn mb-4">Edit Konten</h1>
                <nav aria-label="breadcrumb animated fadeIn">
                    <ol class="breadcrumb text-uppercase">
                        <li class="breadcrumb-item"><a href="index.php" style="color: rgb(45, 45, 204)">Admin</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#" style="color: rgb(21, 21, 173)">Edit</a></li>
                        <li class="breadcrumb-item text-body active" aria-current="page">Edit Konten</li>
                    </ol>
                </nav>
            </div>
            <div class="col-md-6 animated fadeIn">
                <img class="img-fluid" src="img/header.jpg" alt="" />
            </div>
        </div>
    </div>
    <!-- Header End -->

    <!-- Search Start -->
    <div class="container-fluid bg-dark mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 35px">
        <div class="container">
            <div class="row g-2">
                <div class="col-md-10">
                    <div class="row g-2">
                        <div class="col-md-12">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Search End -->

    <!-- Edit Property Start -->
    <div class="container">
        <div class="card">
            <h2 class="mb-4">Add New Property</h2>
            <form action="update_property.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id"
                    value="<?php echo htmlspecialchars($property['id'], ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                <div class="form-group">
                    <label for="title">Property Title:</label>
                    <input type="text" class="form-control" id="title" name="title"
                        value="<?php echo htmlspecialchars($property['title'], ENT_QUOTES, 'UTF-8'); ?>" required>

                </div>

                <div class="form-group">
                    <label for="price">Price:</label>
                    <input type="text" class="form-control" id="price" name="price"
                        value="<?php echo htmlspecialchars($property['price'], ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>

                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" id="description" name="description" rows="4"
                        required><?php echo htmlspecialchars($property['description'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="location">Location:</label>
                    <input type="text" class="form-control" id="location" name="location"
                        value="<?php echo htmlspecialchars($property['location'], ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>

                <div class="form-group">
                    <label for="ruangan">Jumlah Ruangan:</label>
                    <input type="text" class="form-control" id="ruangan" name="ruangan"
                        value="<?php echo htmlspecialchars($property['ruangan'], ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>

                <div class="form-group">
                    <label for="bed">Jumlah Kamar:</label>
                    <input type="text" class="form-control" id="bed" name="bed"
                        value="<?php echo htmlspecialchars($property['bed'], ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>

                <div class="form-group">
                    <label for="bath">Jumlah Kamar Mandi:</label>
                    <input type="text" class="form-control" id="bath" name="bath"
                        value="<?php echo htmlspecialchars($property['bath'], ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>

                <div class="form-group">
                    <label for="status">Property Status:</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="dijual">Dijual</option>
                        <option value="pre-order">Pre-order</option>
                    </select>

                </div>
                <div class="form-group">
                    <label for="type">Property Type:</label>
                    <select class="form-control" id="type" name="type"
                        value="<?php echo htmlspecialchars($property['type'], ENT_QUOTES, 'UTF-8'); ?>" required>
                        <option value="Apartment">Apartment</option>
                        <option value="Villa">Villa</option>
                        <option value="Home">Rumah</option>
                        <option value="Tanah">Tanah</option>
                        <option value="Komersil">Komersil</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="image_link">Link URL Gambar:</label>
                    <input type="text" class="form-control" id="image_link" name="image_link"
                        placeholder="Masukkan URL tujuan gambar"
                        value="<?php echo htmlspecialchars($property['image_link'], ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
                <div class="form-group">
                    <label for="image">Upload Image:</label>
                    <input type="file" class="form-control-file" id="image" name="image[]" multiple required>
                </div>
                <button type="submit" class="btn btn-dark mt-3">Add Property</button>
            </form>
        </div>
    </div>
    <!-- Edit Property End -->

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 footer wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="text-center">
                        &copy; <a href="https://www.instagram.com/griya.idn" target="blank">Copyright PT.
                            Artha Adhi Sentosa
                            NPA REI 01.01695</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
</body>

</html>