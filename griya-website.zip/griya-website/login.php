<?php

require 'vendor/autoload.php';

use Firebase\JWT\JWT;

$error = '';

if(isset($_POST["login"]))
{
	$connect = new PDO("mysql:host=localhost;dbname=griya_idn", "root", "");

	if(empty($_POST["email"])){
		$error = 'Please Enter Email Details';
	} else if(empty($_POST["password"])){
		$error = 'Please Enter Password Details';
	} else {
		$query = "SELECT * FROM user WHERE user_email = ?";
		$statement = $connect->prepare($query);
		$statement->execute([$_POST["email"]]);
		$data = $statement->fetch(PDO::FETCH_ASSOC);
		if($data){
			if($data['user_password'] ===  $_POST['password']){
				$key = '1a3LM3W966D6QTJ5BJb9opunkUcw_d09NCOIJb9QZTsrneqOICoMoeYUDcd_NfaQyR787PAH98Vhue5g938jdkiyIZyJICytKlbjNBtebaHljIR6-zf3A2h3uy6pCtUFl1UhXWnV6madujY4_3SyUViRwBUOP-UudUL4wnJnKYUGDKsiZePPzBGrF4_gxJMRwF9lIWyUCHSh-PRGfvT7s1mu4-5ByYlFvGDQraP4ZiG5bC1TAKO_CnPyd1hrpdzBzNW4SfjqGKmz7IvLAHmRD-2AMQHpTU-hN2vwoA-iQxwQhfnqjM0nnwtZ0urE6HjKl6GWQW-KLnhtfw5n_84IRQ';
				$token = JWT::encode(
					array(
						'iat'		=>	time(),
						'nbf'		=>	time(),
						'exp'		=>	time() + 3600,
						'data'	=> array(
							'user_id'	=>	$data['user_id'],
							'user_name'	=>	$data['user_name']
						)
					),
					$key,
					'HS256'
				);
				setcookie("token", $token, time() + 3600, "/", "", true, true);
				header('location:admin.php');

			} else {
				$error = 'Wrong Password';
			}
		} else {
			$error = 'Wrong Email Address';
		}
	}
}

?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="img/icon.png" rel="icon" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-JtkDK7EeIQFg/0SDptnKsxH3Z/zysp1QO1PE+32Z2MC/6SzzXJt6GJ2J5edOQ1Kr4Oq3Q1LMBa1nzyOx5EY+Rw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Login - Griya ID</title>
</head>
<style>
@import url('https://fonts.googleapis.com/css?family=Poppins');

html {
    background-color: #1e3657;
}

body {
    font-family: "Poppins", sans-serif;
    height: 100vh;
    background-color: #1e3657;

}

a {
    color: #92badd;
    display: inline-block;
    text-decoration: none;
    font-weight: 400;
}

h2 {
    text-align: center;
    font-size: 18px;
    font-weight: 600;
    text-transform: uppercase;
    margin: 40px 8px 10px 8px;
}

.wrapper {
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;
    width: 100%;
    min-height: 100%;
    padding: 20px;
}

#formContent {
    border-radius: 10px;
    background: #ffffff;
    padding: 30px;
    width: 100%;
    max-width: 650px;
    box-shadow: 0 30px 60px 0 rgba(0, 0, 0, 0.3);
    text-align: center;
    opacity: 0;
    transform: scale(0.8);
    transition: all 0.8s cubic-bezier(0.25, 0.8, 0.25, 1);

    input[type=text],
    input[type=password] {
        background-color: #f6f6f6;
        border: none;
        color: #0d0d0d;
        padding: 15px 32px;
        margin: 5px;
        width: 85%;
        border: 2px solid #f6f6f6;
        border-radius: 5px;
        transition: all 0.5s ease-in-out;
    }

    input[type=text]:focus,
    input[type=password]:focus {
        background-color: #fff;
        border-bottom: 2px solid #005f73;
    }

    input[type=submit] {
        background-color: #1261FF;
        border: none;
        color: white;
        padding: 15px 80px;
        text-transform: uppercase;
        font-size: 13px;
        box-shadow: 0 10px 30px 0 rgba(95, 186, 233, 0.4);
        border-radius: 5px;
        margin: 5px 20px 40px 20px;
        transition: all 0.3s ease-in-out;
    }

    input[type=submit]:hover {
        background-color: #00a8e8;
    }

    .back-icon {
        position: absolute;
        top: 10px;
        right: 10px;
        text-decoration: none;
    }
}
</style>

<body>
    <div class="wrapper fadeInDown">
        <div id="formContent">
            <a href="index.php" class="back-icon">
                <i class="fa-solid fa-backward"></i> Kembali
            </a>
            <h2 class="active text-dark"> Sign In </h2>
            <div class="fadeIn first">
                <?php
                if($error !== '') {
                    echo '<div class="alert alert-danger">'.$error.'</div>';
                }
                ?>
            </div>
            <!-- Login Form -->
            <form method="POST" action="">
                <input type="text" id="email" class="fadeIn second" name="email" placeholder="Email">
                <input type="password" id="password" class="fadeIn third" name="password" placeholder="Password">
                <input type="submit" class="fadeIn fourth" name="login" value="Login">
            </form>
            <!-- Remind Password -->
            <div id="formFooter">
                <a class="underlineHover" href="index.php">Forgot Password?</a>
            </div>
        </div>
    </div>
    <script>
    window.onload = function() {
        var formContent = document.getElementById('formContent');
        setTimeout(function() {
            formContent.style.opacity = '1';
            formContent.style.transform = 'scale(1)';
        }, 100);
    };
    </script>
    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-white-50 footer wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="text-center">
                        &copy; <a href="https://www.instagram.com/griya.idn" target="blank">Copyright PT.
                            Artha Adhi Sentosa
                            NPA REI 01.01695</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
</body>

</html>