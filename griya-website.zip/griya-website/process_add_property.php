<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "griya_idn";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$title = $conn->real_escape_string($_POST['title']);
$price = $conn->real_escape_string($_POST['price']);
$description = $conn->real_escape_string($_POST['description']);
$ruangan = (int)$_POST['ruangan'];
$bed = (int)$_POST['bed'];
$bath = (int)$_POST['bath'];
$status = $conn->real_escape_string($_POST['status']);
$location = $conn->real_escape_string($_POST['location']);
$type = $conn->real_escape_string($_POST['type']);
$image_link = $conn->real_escape_string($_POST['image_link']);

$imageNames = [];
$targetDir = "uploads/";

foreach ($_FILES['image']['name'] as $key => $imageName) {
    $fileExtension = pathinfo($imageName, PATHINFO_EXTENSION);
    if (!in_array($fileExtension, ['jpg', 'jpeg', 'png', 'gif'])) {
        echo "Invalid file type.";
        exit();
    }

    $targetFilePath = $targetDir . basename($imageName);
    if (move_uploaded_file($_FILES['image']['tmp_name'][$key], $targetFilePath)) {
        $imageNames[] = $imageName;
    } else {
        echo "Failed to upload file: " . $imageName;
        exit();
    }
}

$imageNamesString = implode(",", $imageNames);

$stmt = $conn->prepare("INSERT INTO properties (title, price, description, location, type, images, bath, ruangan, bed, status, image_link) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssiiiss", $title, $price, $description, $location, $type, $imageNamesString, $bath, $ruangan, $bed, $status, $image_link);

if ($stmt->execute()) {
    header("Location: update_admin.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>