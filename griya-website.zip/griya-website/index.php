<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "griya_idn";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT title, price, description, location, type, images, status, ruangan, bed, bath, image_link FROM properties";
$result = $conn->query($sql);

$properties = [
    'Featured' => [],
    'For Sell' => [],
    'For Rent' => []
];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $status = $row['status'];
        $images = explode(',', $row["images"]);
        
        $properties[$status][] = [
            'title' => $row["title"],
            'price' => $row["price"],
            'description' => $row["description"],
            'location' => $row["location"],
            'type' => $row["type"],
            'ruangan' => $row["ruangan"],
            'bed' => $row["bed"],
            'bath' => $row["bath"],
            'image_link' => $row["image_link"],
            'image' => !empty($images[0]) ? 'uploads/' . $images[0] : 'img/default.jpg',
            'status' => $status
        ];
    }
} else {
    echo "0 hasil";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>GRIYA.ID | WEBSITE</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Favicon -->
    <link href="img/icon.png" rel="icon" />

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap"
        rel="stylesheet" />

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet" />
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet" />
</head>
<style>
.property-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}
</style>

<body style="background-color: #1e3657" id="#top">
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-dark" style="width: 3rem; height: 3rem" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Navbar Start -->
        <div class="container-fluid nav-bar">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
                <a href="index.html" class="navbar-brand d-flex align-items-center text-center">
                    <div class="p-2 me-4">
                        <img class="img-fluid"
                            src="https://griya.id/wp-content/uploads/2024/01/logo-logo-internal-e1705216276269.png"
                            alt="Icon" style="width: 170px; height: 50px" />
                    </div>
                    <h1 style="color: #0d6efd"></h1>
                </a>
                <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto">
                        <a href="#top" class="nav-item nav-link active">Home</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Property</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="https://griya.id/cendana-residence-mlati-sleman/" class="dropdown-item"
                                    target="blank">Cendana
                                    Residence Jombor - Sleman</a>
                                <a href="https://griya.id/artha-residence-pamungkas-sleman/" class="dropdown-item"
                                    target="blank">Artha
                                    Residence Pamungkas -
                                    Sleman</a>
                                <a href="https://griya.id/palm-residence-purwomartani-sleman/" class="dropdown-item"
                                    target="blank">Palm Residence Purwomartani -
                                    Sleman</a>
                                <a href="https://griya.id/mulia-residence-kaliurang-sleman/" class="dropdown-item"
                                    target="blank">Mulia
                                    Residence Kaliurang -
                                    Sleman</a>
                                <a href="cs.php" class="dropdown-item">Taman Mulia Kaliurang (Coming
                                    Soon)
                                    - Sleman</a>
                                <a href="404.php" class="dropdown-item">Citra Pesona Gegunung -
                                    Cirebon</a>
                            </div>
                        </div>
                        <a href="https://griya.id/blog" class="nav-item nav-link" target="blank">Blog</a>
                        <a href="https://s.id/Lowongan-Keren" target="blank" class="nav-item nav-link">Karir</a>
                        <a href="https://wa.me/6288980539898?text=Halo%20Kak%20Arsanti,%20Saya%20minat%20Artha%20Residence%20Pamungkas"
                            target="blank" class="nav-item nav-link">Contact</a>
                    </div>
                    <a href="login.php" class="btn btn-dark px-3 d-none d-lg-flex">Add Property</a>
                </div>
            </nav>
        </div>
        <!-- Navbar End -->

        <!-- Header Start -->
        <div class="container-fluid header bg-white p-0">
            <div class="row g-0 align-items-center flex-column-reverse flex-md-row">
                <div class="col-md-6 p-5 mt-lg-5">
                    <h1 class="display-5 animated fadeIn mb-4">Bantu <span style="color: #0054d1">kamu
                            Miliki</span> Rumah Baru.</h1>
                    <p class="animated fadeIn mb-4 pb-2">Temukan hunian impian Anda dengan Griya.ID, pengembang
                        terpercaya yang menawarkan berbagai pilihan properti berkualitas. Miliki rumah idaman yang
                        nyaman dan aman, sekaligus berinvestasi untuk masa depan yang cerah. Dengan Griya.ID, impian
                        memiliki rumah kini lebih mudah diwujudkan. Mulai perjalanan investasi Anda bersama kami!</p>
                    <a href="#satu" class="btn btn-dark py-3 px-5 me-3 animated fadeIn">Get Started</a>
                </div>
                <div class="col-md-6 animated fadeIn">
                    <div class="owl-carousel header-carousel">
                        <div class="owl-carousel-item">
                            <img class="img-fluid" src="img/mulia-1.png" alt="" />
                        </div>
                        <div class="owl-carousel-item">
                            <img class="img-fluid" src="img/purwo-1.png" alt="" />
                        </div>
                        <div class="owl-carousel-item">
                            <img class="img-fluid" src="img/cendana-1.png" alt="" />
                        </div>
                        <div class="owl-carousel-item">
                            <img class="img-fluid" src="img/artha-1.png" alt="" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header End -->

        <!-- Search Start -->
        <div class="container-fluid bg-dark mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 35px">
            <div class="container">
                <div class="row g-2">
                    <div class="col-md-10">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <input type="text" id="searchInput" class="form-control border-0 py-3"
                                    placeholder="Search Keyword" oninput="highlightText()" />
                            </div>
                            <div class="col-md-4">
                                <select class="form-select border-0 py-3" id="satu">
                                    <option selected>Property Type</option>
                                    <option value="1">43/80</option>
                                    <option value="2">43/80+</option>
                                    <option value="3">43/80++</option>
                                    <option value="4">47/80</option>
                                    <option value="5">50/84</option>
                                    <option value="6">50/84+</option>
                                    <option value="7">50/84++</option>
                                    <option value="8">95/100++</option>
                                    <option value="9">80/102</option>
                                    <option value="10">100/802</option>
                                    <option value="11">100/110++</option>
                                    <option value="12">80/122</option>
                                    <option value="13">90/100+</option>
                                    <option value="14">100/100++</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select class="form-select border-0 py-3">
                                    <option selected>Location</option>
                                    <option value="1">Jombor, Sleman</option>
                                    <option value="2">Kaliurang, Sleman</option>
                                    <option value="3">Purwomartani, Sleman</option>
                                    <option value="4">Jangkang, Sleman</option>
                                    <option value="5">Pamungkas, Sleman</option>
                                    <option value="6">Godean, Sleman</option>
                                    <option value="7">Wonosalam, Sleman</option>
                                    <option value="8">Gegunung, Cirebon</option>
                                    <option value="9">Wonosobo, Cirebon</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary border-0 w-100 py-3"><a
                                href="https://wa.me/6288980539898?text=Halo%20Kak%20Arsanti,%20Saya%20minat%20Artha%20Residence%20Pamungkas"
                                class="text-light" target="blank">#WAAjaDulu</a></button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Search End -->

        <!-- Rumah Dijual -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-0 gx-5 align-items-end">
                    <div class="col-lg-6">
                        <div class="text-start mx-auto mb-5 wow slideInLeft" data-wow-delay="0.1s">
                            <h1 class="mb-3">Rumah Dijual</h1>
                            <p>Temukan rumah impianmu dengan mudah dan cepat hanya di sini!</p>
                        </div>
                    </div>
                    <div class="col-lg-6 text-start text-lg-end wow slideInRight" data-wow-delay="0.1s">
                        <ul class="nav nav-pills d-inline-flex justify-content-end mb-5">
                            <li class="nav-item me-2">
                                <a class="btn btn-outline-dark active ps-4 pe-4" data-bs-toggle="pill"
                                    href="#tab-1">All</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="btn btn-outline-dark" data-bs-toggle="pill" href="#tab-2">For Sell</a>
                            </li>
                            <li class="nav-item me-0">
                                <a class="btn btn-outline-dark" data-bs-toggle="pill" href="#tab-3">Pre-Order</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane fade show p-0 active">
                        <div class="row g-4">
                            <?php foreach ($properties as $status => $items): ?>
                            <?php foreach ($items as $item): ?>
                            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                                <div class="property-item rounded overflow-hidden">
                                    <div class="position-relative overflow-hidden">
                                        <a href="<?php echo htmlspecialchars($item['image_link'], ENT_QUOTES, 'UTF-8'); ?>"
                                            target="_blank">
                                            <img class="img-fluid"
                                                src="<?php echo htmlspecialchars($item['image'], ENT_QUOTES, 'UTF-8'); ?>"
                                                alt="<?php echo htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8'); ?>" />
                                        </a>
                                        <!-- expand icon -->
                                        <a href="<?php echo htmlspecialchars($item['image'], ENT_QUOTES, 'UTF-8'); ?>"
                                            target="_blank" class="btn btn-primary position-absolute top-0 end-0 m-2">
                                            <i class="fa fa-expand"></i>
                                        </a>
                                        <div
                                            class="bg-dark rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3">
                                            <?php echo htmlspecialchars($item['status'], ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                        <div
                                            class="bg-white rounded-top text-dark position-absolute start-0 bottom-0 mx-4 pt-1 px-3">
                                            <?php echo htmlspecialchars($item['type'], ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                    </div>
                                    <div class="p-4 pb-0">
                                        <h5 class="text-dark mb-3">
                                            Rp <?php echo htmlspecialchars($item['price'], ENT_QUOTES, 'UTF-8'); ?>
                                        </h5>
                                        <a class="d-block h5 mb-2"
                                            href="<?php echo htmlspecialchars($item['image_link'], ENT_QUOTES, 'UTF-8'); ?>"
                                            target="blank"><?php echo htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8'); ?></a>
                                        <p><i
                                                class="fa fa-map-marker-alt text-dark me-2"></i><?php echo htmlspecialchars($item['location'], ENT_QUOTES, 'UTF-8'); ?>
                                        </p>
                                    </div>
                                    <div class="d-flex border-top">
                                        <small class="flex-fill text-center border-end py-2"><i
                                                class="fa fa-cube text-dark me-2"></i><?php echo htmlspecialchars($item['ruangan'], ENT_QUOTES, 'UTF-8'); ?>
                                            Ruangan</small>
                                        <small class="flex-fill text-center border-end py-2"><i
                                                class="fa fa-bed text-dark me-2"></i><?php echo htmlspecialchars($item['bed'], ENT_QUOTES, 'UTF-8'); ?>
                                            Kamar</small>
                                        <small class="flex-fill text-center py-2"><i
                                                class="fa fa-bath text-dark me-2"></i><?php echo htmlspecialchars($item['bath'], ENT_QUOTES, 'UTF-8'); ?>
                                            Kamar Mandi</small>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php endforeach; ?>
                            <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.1s">
                                <a class="btn btn-dark py-3 px-5" href="https://griya.id/">More Property</a>
                            </div>
                        </div>
                    </div>
                    <div id="tab-2" class="tab-pane fade show p-0">
                        <div class="row g-4">
                        </div>
                    </div>
                    <div id="tab-3" class="tab-pane fade show p-0">
                        <div class="row g-4">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Rumah Dijual -->

        <br>
        <br>
        <br>

        <!-- Blog Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                        <div class="about-img position-relative overflow-hidden p-5 pe-0">
                            <img class="img-fluid w-60" src="img/blog.png">
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <h1 class="mb-4">Jelajahi Artikel Menarik di Griya.ID dan Temukan Inspirasi Untuk Mewujudkan
                            Rumah Impian Anda</h1>
                        <p class="mb-4">Jelajahi artikel-artikel menarik di Griya.ID dan temukan berbagai inspirasi
                            untuk mewujudkan rumah impian Anda! Kami menyajikan berbagai tips, panduan, dan ide kreatif
                            yang dapat membantu Anda dalam merancang dan memilih hunian yang sempurna. Dari desain
                            interior yang elegan hingga solusi inovatif untuk kebutuhan rumah tangga, setiap artikel
                            kami dirancang untuk memberikan wawasan dan motivasi.</p>
                        <p> Ayo, mulai petualangan Anda bersama Griya.ID
                            dan wujudkan rumah impian Anda hari ini!</p>
                        <a class="btn btn-dark py-3 px-5 mt-3" href="https://griya.id/blog" target="blank">Get
                            Started</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Blog End -->

        <!-- Call to Action Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="bg-light rounded p-3">
                    <div class="bg-white rounded p-4" style="border: black">
                        <div class="row g-5 align-items-center">
                            <!-- Bagian teks -->
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                                <div class="mb-4">
                                    <h1 class="mb-3">Ingin Tahu Lebih Banyak? Hubungi Hami Untuk Detail Selengkapnya!
                                    </h1>
                                    <p>Apakah Anda ingin mendapatkan informasi lebih lanjut tentang produk atau layanan
                                        kami? Jangan ragu untuk menghubungi Hami! Kami siap membantu menjawab pertanyaan
                                        Anda dan memberikan detail lengkap yang Anda butuhkan.</p>
                                </div>
                                <a href="https://wa.me/6288980539898?text=Halo%20Kak%20Arsanti,%20Saya%20minat%20Palm%20Residence%20Purwomartani"
                                    class="btn btn-primary py-3 px-4 me-2" target="_blank"><i
                                        class="fa fa-phone-alt me-2"></i>#WAAjaDulu</a>
                            </div>
                            <!-- Bagian gambar -->
                            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                                <img class="img-fluid rounded w-100" src="img/contact.png" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Call to Action End -->

        <!-- Karir Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Gabung Bersama Kami!</h1>
                    <p>Bergabunglah dengan Griya.ID dan kembangkan karir Anda di dunia properti! Bersama kami, wujudkan
                        potensi dan kontribusi Anda dalam membantu orang lain menemukan hunian impian</p>
                    <a href="https://s.id/Lowongan-Keren" class="btn btn-dark py-3 px-4 me-2" target="_blank">Get
                        Started</a>
                </div>
                <br>
                <div class="row g-4">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item rounded overflow-hidden">
                            <div class="position-relative">
                                <!-- <img class="img-fluid" src="karir/3.jpg" alt=""> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Karir End -->

        <!-- Footer Start -->
        <div class="container-fluid bg-dark text-white-50 footer wow fadeIn" data-wow-delay="0.1s">
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="text-center">
                            &copy; <a href="https://www.instagram.com/griya.idn" target="blank">Copyright PT.
                                Artha Adhi Sentosa
                                NPA REI 01.01695</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->

        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    <!-- Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Image Preview</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <img id="modalImage" src="" class="img-fluid" alt="Full screen image" />
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const expandButtons = document.querySelectorAll('.btn-expand');
        const modalImage = document.getElementById('modalImage');
        expandButtons.forEach(button => {
            button.addEventListener('click', function() {
                const imageUrl = this.getAttribute('data-image');
                modalImage.src = imageUrl;
            });
        });
    });
    </script>
</body>

</html>