<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "griya_idn";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$imageNames = [];
$targetDir = "jobs/";

foreach ($_FILES['image']['name'] as $key => $imageName) {
    // Validasi tipe file
    $fileType = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    
    if (in_array($fileType, $allowedTypes)) {
        $newFileName = time() . '_' . basename($imageName);
        $targetFilePath = $targetDir . $newFileName;

        if (move_uploaded_file($_FILES['image']['tmp_name'][$key], $targetFilePath)) {
            $imageNames[] = $newFileName;
        } else {
            echo "Failed to upload file: " . $imageName;
            exit();
        }
    } else {
        echo "Invalid file type: " . $imageName;
        exit();
    }
}

$imageNamesString = implode(",", $imageNames);

$stmt = $conn->prepare("INSERT INTO member (images) VALUES (?)");
$stmt->bind_param("s", $imageNamesString);

if ($stmt->execute()) {
    header("Location: index.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>