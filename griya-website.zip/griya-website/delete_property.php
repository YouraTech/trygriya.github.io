<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "griya_idn";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$id = intval($_GET['id']);

$sql = "SELECT images FROM properties WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row) {
    $images = explode(',', $row['images']);
    foreach ($images as $image) {
        $filePath = 'uploads/' . $image;
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }

    $sql = "DELETE FROM properties WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: update_admin.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    echo "Data tidak ditemukan.";
}

$stmt->close();
$conn->close();
?>